package com.example.metrestoinches;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOError;

public class MainActivity extends AppCompatActivity {

    private boolean flag  = false;

    private Button one, two, three, four, five, six, seven, eight, nine, point, zero, backspace,clearall, convert, swap;
    private TextView entry, result, t1, t2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        one = (Button)findViewById(R.id.one);
        two = (Button)findViewById(R.id.two);
        three = (Button)findViewById(R.id.three);
        four = (Button)findViewById(R.id.four);
        five = (Button)findViewById(R.id.five);
        six = (Button)findViewById(R.id.six);
        seven = (Button)findViewById(R.id.seven);
        eight = (Button)findViewById(R.id.eight);
        nine = (Button)findViewById(R.id.nine);
        zero = (Button)findViewById(R.id.zero);
        point = (Button)findViewById(R.id.point);
        clearall = (Button)findViewById(R.id.clearall);
        convert = (Button)findViewById(R.id.convert);
        swap = (Button)findViewById(R.id.swap);
        backspace = (Button)findViewById(R.id.backspace);
        entry = (TextView)findViewById(R.id.entry);
        result = (TextView)findViewById(R.id.result);
        t1 = (TextView)findViewById(R.id.measure1);
        t2 = (TextView)findViewById(R.id.measure2);


        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                entry.setText(entry.getText().toString() + '1');
            }
        });
        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                entry.setText(entry.getText().toString() + '2');
            }
        });
        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                entry.setText(entry.getText().toString() + '3');
            }
        });
        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                entry.setText(entry.getText().toString() + '4');
            }
        });
        five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                entry.setText(entry.getText().toString() + '5');
            }
        });
        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                entry.setText(entry.getText().toString() + '6');
            }
        });
        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                entry.setText(entry.getText().toString() + '7');
            }
        });
        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                entry.setText(entry.getText().toString() + '8');
            }
        });
        nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                entry.setText(entry.getText().toString() + '9');
            }
        });
        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                entry.setText(entry.getText().toString() + '0');
            }
        });
        point.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = entry.getText().toString();
                if (str.contains(".")){}
                else{
                    entry.setText(str + ".");
                }
            }
        });
        backspace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = entry.getText().toString();
                if (str != null && str.length() > 0) {
                    str = str.substring(0, str.length() - 1);
                }
                entry.setText(str);
            }
        });
        swap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = t1.getText().toString();
                t1.setText(t2.getText().toString());
                t2.setText(str);
                if (flag==false){
                    flag = true;
                }
                else{
                    flag = false;
                }
            }
        });
        convert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String number = entry.getText().toString();
                    if (flag == false) {
                        Double metres = Double.parseDouble(number);
                        Double inches = metres * 39.3701;
                        result.setText(Double.toString(inches));
                    } else {
                        Double inches = Double.parseDouble(number);
                        Double metres = inches * 0.0254;
                        result.setText(Double.toString(metres));
                    }
                }
                catch (NumberFormatException e){}
            }
        });
        clearall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                entry.setText(null);
                result.setText("RESULT");
                t1.setText("Metres");
                t2.setText("Inches");
                flag = false;
            }
        });
    }
}
