package com.example.randomcolorchanger;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.Constraints;

import android.graphics.Color;
import android.media.Image;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private LinearLayout parent;
    private Button buttonclick;
    private int previouscolor;
    private int[] colors;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonclick = (Button)findViewById(R.id.button);
        parent = (LinearLayout) findViewById(R.id.parentlayout);

        colors = new int[]{Color.RED, Color.YELLOW, Color.BLUE, Color.GREEN, Color.CYAN, Color.MAGENTA, Color.GRAY};
        buttonclick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int newcolor = colors[randomnumber()];
                while(true){
                    if (previouscolor == newcolor){
                        newcolor = colors[randomnumber()];
                    }
                    else
                    {
                        break;
                    }
                }
                parent.setBackgroundColor(newcolor);
                previouscolor = newcolor;
            }
        });
    }

    protected int randomnumber(){
        Random random = new Random();
        int randomnum = random.nextInt(colors.length);
        return randomnum;
    }
}
